To provide backwards functionality for WooCommerce < 2.4 an entire snapshot of the 1.7.1
release is included inside of the core 2.0.0 version.  

Eventually we can remove this once everyone is on at least WooCommerce 2.4

